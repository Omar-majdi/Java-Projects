package com.omar;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
//        for (int i = 1; i <= 6; i++) {
//            for (int j = 1; j <= i; j++)
//                System.out.print(j);
//            for (int k = 6; k > i; k--)
//                System.out.print("*");
//            System.out.println();
//        }
//        for (int i = 6; i >= 1; i--) {
//            for (int j = 1; j < i; j++) {
//                System.out.print(j);
//            }
//            for (int k = 6; k >= i; k--) {
//                System.out.print("&");
//            }
//
//            System.out.println();
//        }
//        System.out.println();
//		System.out.println("@");
//		for(int i = 5; i >= 1; i--) {
//			System.out.print("@");
//			for(int j = 5; j >= i; j--) {
//				System.out.print(" ");
//			}
//			System.out.println("@");
//		}
//		for(int j = 5; j> 0; j--) {
//			System.out.print("@ ");
//		}


//        Scanner input = new Scanner(System.in);
//        int n;
//
//        do {
//            System.out.print("Enter the number of lines: ");
//            n = input.nextInt();
//        }
//        while (n <= 0);
//
//        for (int i = 1; i <= n; i++) {
//            for (int j = 1; j <= i; j++) {
//                System.out.print("*");
//            }
//            System.out.println();
//        }


    }

        }





