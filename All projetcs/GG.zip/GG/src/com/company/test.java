package com.company;

public class test {
String liquidType = "Coffee";


}
