package com.company;
import java.time.Period;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class Main {



    public static void main(String[] args) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        LocalDate today = LocalDate.now();
        LocalDate birthday = LocalDate.parse("5/7/2005", formatter);


        Period p = Period.between(birthday, today);
        System.out.println("You are " + p.getYears() + " years, " + p.getMonths() +
                " months and " + p.getDays() +
                " days old.");
    }
}



