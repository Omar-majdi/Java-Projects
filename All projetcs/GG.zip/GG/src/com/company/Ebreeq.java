package com.company;

public class Ebreeq {
    public Object liquidType;
    String liqidType = "Coffee";
}
