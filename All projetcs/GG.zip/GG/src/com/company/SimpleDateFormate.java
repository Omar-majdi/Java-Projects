package com.company;

public class SimpleDateFormate {
    public SimpleDateFormate(String s) {
    }
}
