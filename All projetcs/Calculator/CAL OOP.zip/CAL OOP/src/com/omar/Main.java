package com.omar;

public class Main {

    public static void main(String[] args) {

        System.out.println("1-Addition");
        System.out.println("2-Subtraction");
        System.out.println("3-Multiplication");
        System.out.println("4-Division");
        System.out.println("5-Power");
        System.out.println("6-Absolute");
        System.out.println("7-Compute area");
        System.out.println("8-Minimum");
        System.out.println("9-Maximum");
        System.out.println("10-Sqrt");

        Calculation.calculate();
    }

}




