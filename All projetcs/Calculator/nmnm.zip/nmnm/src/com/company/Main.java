package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        System.out.println("1-Addition");
        System.out.println("2-Subtraction");
        System.out.println("3-Multiplication");
        System.out.println("4-Division");
        System.out.println("5-Power");
        System.out.println("6-Absolute");
        System.out.println("7-Compute area");
        System.out.println("8-Minimum");
        System.out.println("9-Maximum");
        System.out.println("10-Sqrt");


        Boolean isLooping = true;
        Scanner s = new Scanner(System.in);
        while (isLooping) {
            System.out.println("Enter your choice: ");
            int choice = s.nextInt();


            int first, second;
            switch (choice) {
                case 1:
                    System.out.println("Enter the first number");
                    first = s.nextInt();
                    System.out.println("Enter the second number");
                    second = s.nextInt();
                    System.out.println("The sum of " + first + " and " + second + " is: " + (first + second));
                    break;
                case 2:
                    System.out.println("Enter the first number");
                    first = s.nextInt();
                    System.out.println("Enter the second number");
                    second = s.nextInt();
                    System.out.println("The sub of " + first + " and " + second + " is: " + (first - second));
                    break;
                case 3:
                    System.out.println("Enter the first number");
                    first = s.nextInt();
                    System.out.println("Enter the second number");
                    second = s.nextInt();
                    System.out.println("The mul of " + first + " and " + second + " is: " + (first * second));
                    break;
                case 4:
                    System.out.println("Enter the first number");
                    first = s.nextInt();
                    System.out.println("Enter the second number");
                    second = s.nextInt();
                    System.out.println("The div of " + first + " by " + second + " is: " + (first / second));
                    break;
                case 5:
                    System.out.println("Enter the first number");
                    first = s.nextInt();
                    System.out.println("Enter the second number");
                    second = s.nextInt();
                    System.out.println("The power of " + first + " to the " + second + " is: " + (Math.pow(first, second)));
                    break;
                case 6:
                    System.out.println("Enter the number");
                    first = s.nextInt();

                    System.out.println("The Abs of " + first + " is: " + (Math.abs(first)));
                    break;
                case 7:
                    System.out.println("Enter the width");
                    first = s.nextInt();
                    System.out.println("Enter the height");
                    second = s.nextInt();
                    System.out.println("The Area of " + first + " and " + second + " is: " + (first * second));
                    break;
                case 8:
                    System.out.println("Enter the first number");
                    first = s.nextInt();
                    System.out.println("Enter the second number");
                    second = s.nextInt();
                    System.out.println("The Min of " + first + " and " + second + " is: " + (Math.min(first, second)));
                    break;
                case 9:
                    System.out.println("Enter the first number");
                    first = s.nextInt();
                    System.out.println("Enter the second number");
                    second = s.nextInt();
                    System.out.println("The Max of " + first + " and " + second + " is: " + (Math.max(first, second)));
                    break;
                case 10:
                    System.out.println("Enter the number");
                    first = s.nextInt();

                    System.out.println("The Sqrt of " + first + " is: " + (Math.sqrt(first)));
                    break;
                case 11:
                    System.out.println("Enter the  number");
                    first = s.nextInt();

                    System.out.println("The sin of " + first + " is: " + (Math.asin(first)));
                    break;

                default:
                    System.out.println("Invalid choice");


            }
            System.out.println("Do you need more time? (yes/no)");
            String yesOrNo = s.next();
            if (yesOrNo.toLowerCase().equals("no")) isLooping = false;
        }


    }
}


