package com.omar;

public class Main {

    public static void main(String[] args) {
        //This code was written in 2/10/2020

        Account omar = new Account("Omar Majdi", "123456");
        //omar.showMenu();
        Account majdi = new Account("Majdi Saleh","1234567");
        //majdi.showMenu();
        Account moad =new Account("Moad Saleh","12345678");
        //moad.showMenu();
        Account baraa = new Account("Baraa Majdi","145632");
        baraa.showMenu();
    }
}
