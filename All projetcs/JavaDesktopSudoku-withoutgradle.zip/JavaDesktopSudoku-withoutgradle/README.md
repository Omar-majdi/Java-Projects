This project is used as a learning resource for my course, Working Class Java.

In order to actually build and launch this project, you will need to configure some kind of build tool. I have included the build.gradle and settings.gradle files, which should allow you to set the project up using Gradle, should that be your preferred tool. 

The easiest solution would be to create a new Gradle project in your preferred IDE, and then copy and paste the source files, and the gradle files form this repo over to the new project.