package com.wiseassblog.sudoku.constants;

public enum GameState {
    COMPLETE,
    ACTIVE,
    NEW
}
