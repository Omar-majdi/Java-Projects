package com.wiseassblog.sudoku.constants;

public class Messages {
    public static final String GAME_COMPLETE = "Congratulations, you have won! New Game?";
    public static final String ERROR = "An error has occured.";
}
